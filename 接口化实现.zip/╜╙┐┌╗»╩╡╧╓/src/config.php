<?php

return [
    // 客户端调用方式 http,tcp
    'type' => 'http',
    //监听地址
    'base_url' => '127.0.0.1:2345',
    //安全秘钥，设置安全密钥需要在请求头或者参数附带key，
    'safe_key' => '',
    // 开启任务日志
    'log' => false
];
